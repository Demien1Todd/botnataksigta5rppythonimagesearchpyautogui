import pyautogui
from python_imagesearch.imagesearch import * 

while True:
    button = imagesearch("pr.jpg")
    if button[0] != -1:
        pyautogui.click(button)
    else:
        print("Ха лох")

